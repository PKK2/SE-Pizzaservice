package de.se.PizzaService.gui;

public class Pizza  {
	
	public static void main(String[] args) {
		
	//	GUI gui = new GUI();
		
	}


}



